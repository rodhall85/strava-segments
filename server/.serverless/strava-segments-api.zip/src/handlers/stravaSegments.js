const axios = require('axios');

const stravaApiUrl = 'https://www.strava.com';
const clientId = 34566;
const redirectUrl = 'http://localhost:3000';

module.exports.getToken = async (event) => {
  if (!event) {
    return new Promise((resolve) => {
      resolve({
        statusCode: 400,
        headers: {
          my_header: 'my_value',
        },
        body: JSON.stringify({ error: 'missing authorisationCode in request' }),
        isBase64Encoded: false,
      });
    });
  }

  const authorisationCode = event['queryStringParameters']['authorisationCode'];

  console.log('auth', authorisationCode);

  const response = await axios.post(`${stravaApiUrl}/oauth/token`, {
    client_id: clientId,
    client_secret: '5a58655aff14f3d82f06f86e0618a3c56df64d11',
    code: '2350dcef9ac5243056d7d07e2b558331ba29e144',
    grant_type: 'authorization_code',
  });


  return new Promise((resolve) => {
    resolve({
      statusCode: response.status,
      headers: {
        my_header: 'my_value',
      },
      body: JSON.stringify({ message: 'responseBody' }),
      isBase64Encoded: false,
    });
  });
};



// authenticate - Call authenticate, get response,
// then validate token to get access_token. Return access_token.
